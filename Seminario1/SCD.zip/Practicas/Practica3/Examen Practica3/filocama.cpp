//Alvaro Perez Luque 53669080Y


#include "mpi.h"
#include <iostream>
#include <time.h>
#include "math.h"
#include <stdlib.h>


using namespace std;

#define Levantarse 3
#define Sentarse 2
#define CojerTenedor 0
#define SoltarTenedor 1
#define Cama_rero 10


int tenedores[10];

void EstablecerTenedores(int nveces){

	for (int i=0; i<5; i++)
			tenedores[i] = nveces; //Cada tenedor puede usarse 3 veces.

}


//Funcion Filosofo
void Filosofo(int id, int nprocesos){
  int izq=(id+1)%nprocesos;
  int der=(id-1+nprocesos)%nprocesos;

	int nveces, finalizo =-1, numfilosofos=5;
	 MPI_Status status; 


 while(1){
		//Solicita al camarero sentarse
		cout<<"Se han sentado en la mesa el Filosofo " << id <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, Cama_rero, Sentarse, MPI_COMM_WORLD);

		 		
  	//Solicita tenedor izquierdo
  	cout<<"Filosofo "<<id<< " solicita tenedor izq ..."<<izq <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, izq, CojerTenedor, MPI_COMM_WORLD); //peticion para cojer al tenedor izq 
		MPI_Recv( &nveces, 1, MPI_INT, izq, CojerTenedor, MPI_COMM_WORLD,&status);
			if (nveces == 0){
				MPI_Ssend(&finalizo, 1, MPI_INT, Cama_rero, Levantarse, MPI_COMM_WORLD);
				cout<<"Filosofo "<<id<< " no puede cojer tenedor y se levanta de la mesa"  <<endl<<flush;
			}	
  
  	//Solicita tenedor derecho
  	cout<<"Filosofo "<<id<< " coge tenedor der ..."<<der <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, der, CojerTenedor, MPI_COMM_WORLD); //peticion para cojer el tenedor der 
			MPI_Recv( &finalizo, 1, MPI_INT, der, CojerTenedor, MPI_COMM_WORLD,&status);
				if (nveces == 0){
				MPI_Ssend(&id, 1, MPI_INT, Cama_rero, Levantarse, MPI_COMM_WORLD);
				cout<<"Filosofo "<<id<< " no puede cojer tenedor y se levanta de la mesa"  <<endl<<flush;
			}	
	
  	cout<<"Filosofo "<<id<< " COMIENDO"<<endl<<flush;
  	sleep((rand() % 3)+1);  //comiendo
	

  //suelta el tenedor izquierdo
  cout<<"Filosofo "<<id<< " suelta tenedor izq ..."<<izq <<endl<<flush;
  MPI_Ssend(&id, 1, MPI_INT, izq, SoltarTenedor, MPI_COMM_WORLD); //Soltamos el tenedor izq 

  //suelta el tenedor derecho
  cout<<"Filosofo "<<id<< " suelta tenedor der ..."<<der <<endl<<flush;
	MPI_Ssend(&id, 1, MPI_INT, der, SoltarTenedor, MPI_COMM_WORLD); //Soltamos el tenedor der

	//Peticion para leventarse de la mesa
	cout<<"Se han levantado de la mesa el Filosofo " << id <<endl<<flush;
	MPI_Ssend(&id, 1, MPI_INT, Cama_rero, Levantarse, MPI_COMM_WORLD);

  cout<<"Filosofo "<<id<< " PENSANDO"<<endl<<flush;
  sleep((rand()%3)+1 );//pensando
 }
}

//Funcion Tenedor
void Tenedor(int id){
  int buf, Filo, valor;
  MPI_Status status; 

  while(1){
    // Espera un peticion desde cualquier filosofo vecino ...	
    // Recibe la peticion del filosofo ...

		//Esperamos cualquier peticion de cojer tenedor y cargamos status del filosofo que es.
		MPI_Recv( &Filo, 1, MPI_INT, MPI_ANY_SOURCE, CojerTenedor, MPI_COMM_WORLD,&status); 
	if (tenedores[id] < 1){
			valor = 0;
			MPI_Ssend(&valor, 1, MPI_INT, status.MPI_SOURCE, CojerTenedor, MPI_COMM_WORLD); 
			cout<<"Ten. "<<id<< " no se puede usar mas veces" <<endl<<flush;
	} else {
			valor = tenedores[id];
			tenedores[id]--;
			MPI_Ssend(&valor, 1, MPI_INT, status.MPI_SOURCE, CojerTenedor, MPI_COMM_WORLD); 
			cout<<"Ten. "<<id<<" recibe petic. de "<<Filo<<endl<<flush;
	}	  
		
    
		// Espera a que el filosofo suelte el tenedor...
		//Utilizamos status por que el mismo filosofo que coje el tenedero debe sortarlo.
    MPI_Recv( &buf, 1, MPI_INT, status.MPI_SOURCE, SoltarTenedor, MPI_COMM_WORLD,&status);  		  
    cout<<"Ten. "<<id<<" recibe liberac. de "<<Filo<<endl<<flush; 
  }
}

//Funcion Camarero
void Camarero(){

	int nsentados = 0, valor, numfilosofos=5; //Controla el numero de filosofos que hay sentados
	MPI_Status status; 
	bool sigue = true;

	while(sigue){
		if (nsentados < 4)//Si hay sitio para sentarse esperamos una peticion de Sentarse o de Levantarse
			MPI_Recv( &valor, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,&status); 
		else {//Si no se puede sentar, esperamos hasta recibir una peticion de Levantarse
			MPI_Recv( &valor, 1, MPI_INT, MPI_ANY_SOURCE, Levantarse, MPI_COMM_WORLD,&status); 
	  }

		if(status.MPI_TAG == Sentarse){
			// Recibe la peticion del filosofo para sentarse	
			nsentados++;
			cout<<"Camarero recibe una penticion para sentarse, hay "<< nsentados <<" filosofos sentados."<<endl<<flush;			 	
		}else{ 		
			//Recibe la peticion del filosofo para Levantarse	
			if(valor == -1)
				numfilosofos--; 

  		nsentados--;
			cout<<"Camarero recibe una penticion para levantarse, hay "<< nsentados << " filosfos sentados." <<endl<<flush;	

		 	if(numfilosofos == 0){
					sigue = false;
					cout << "El camarero ha terminado"<<endl<<flush;	
			}
		
		}
	}
}

int main(int argc,char** argv ){
 int rank,size;
 srand(time(0));

 MPI_Init( &argc, &argv );
 MPI_Comm_rank( MPI_COMM_WORLD, &rank );
 MPI_Comm_size( MPI_COMM_WORLD, &size );

 if( size!=11){
   if(rank == 0) 
      cout<<"El numero de procesos debe ser 10"<<endl<<flush;

   MPI_Finalize( ); return 0; 
 }

	int nveces = 3;
	EstablecerTenedores(nveces); //Estable que n veces se puede usar cada tenedor

	if (rank == 10)
		Camarero();
 	else { if ((rank%2) == 0)
					Filosofo(rank,size-1); // Los pares son Filosofos 
			 	 else
					 Tenedor(rank);  // Los impares son Tenedores 
	}	
						
 MPI_Finalize();

 return 0;
}  

