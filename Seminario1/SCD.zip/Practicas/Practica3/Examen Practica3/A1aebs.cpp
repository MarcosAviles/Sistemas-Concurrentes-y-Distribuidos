
#include <iostream>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <mpi.h>

#define NUM_PROD      6  // número de productores
#define NUM_CONS      5  // número de consumidores
#define ITERS_PROD   15  // número de items producidos por cada productor.
#define TAM           5  // tamaño del vector
#define TAG_PROD      0  // etiqueta usada por los productores
#define TAG_CONS      1  // etiqueta usada por los receptores
#define RANK_BUFFER   NUM_PROD               // índice del proceso buffer
#define NUM_PROCESOS  (NUM_PROD+NUM_CONS+1)  // número total de procesos

using namespace std;

void funcion_productor() ;
void funcion_buffer() ;
void funcion_consumidor() ;
void dormir( double secs_min, double secs_max ) ;

// ---------------------------------------------------------------------

int main( int argc, char *argv[] ) 
{
   int rank, size; 
       
   MPI_Init( &argc, &argv );
   MPI_Comm_rank( MPI_COMM_WORLD, &rank );
   MPI_Comm_size( MPI_COMM_WORLD, &size );
  
   if ( size != NUM_PROCESOS ) 
   {  cout<< "El numero de procesos debe ser "<< NUM_PROCESOS <<endl;
      return 0;
   } 
   
   if ( rank < RANK_BUFFER )       funcion_productor();
   else if ( rank > RANK_BUFFER )  funcion_consumidor();
   else                            funcion_buffer();
      
   MPI_Finalize( );
   return 0;
}
// ---------------------------------------------------------------------

void funcion_productor()
{
   int value;  
   for( unsigned i = 0 ; i < ITERS_PROD ; i++ )
   { 
      value = i ;
      cout << "Productor produce valor " << value << endl << flush ;
      MPI_Ssend( &value, 1, MPI_INT, RANK_BUFFER, TAG_PROD, MPI_COMM_WORLD );
      dormir( 0.2, 0.4 ) ;
   }
   cout << "fin del productor." << endl << flush ;
}
// ---------------------------------------------------------------------

void funcion_consumidor()
{
   int valor_rec, peticion = 1 ;
   MPI_Status status;
   
   for( unsigned int i=0 ; i < (ITERS_PROD*NUM_PROD)/NUM_CONS ; i++ )
   {
     MPI_Ssend( &peticion, 1, MPI_INT, RANK_BUFFER, TAG_CONS, MPI_COMM_WORLD); 
      MPI_Recv ( &valor_rec,    1, MPI_INT, RANK_BUFFER, TAG_CONS, MPI_COMM_WORLD, &status );
      cout << "Consumidor recibe valor " << valor_rec << " de Buffer (raiz == " << sqrt(valor_rec) << ")" << endl << flush ;
      dormir( 0.2, 0.4 ) ;      
   }
   cout << "fin del consumidor." << endl << flush ;
}

// ---------------------------------------------------------------------

void funcion_buffer()
{
   int  buffer[TAM], pos = 0, rama, peticion ;
   MPI_Status status;
   
   for( unsigned int i=0 ; i < 2*(ITERS_PROD*NUM_PROD) ; i++ )
   {  
      // calcular que procesos pueden enviar:
      if      ( pos == 0 )   rama = 0 ; // el consumidor no puede consumir  
      else if ( pos == TAM ) rama = 1 ; // el productor no puede producir 
      else                              // ambas guardas son ciertas:
      {  // ver datos del siguiente mensaje a recibir
         MPI_Probe( MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status );
         if ( status.MPI_SOURCE < RANK_BUFFER ) rama = 0 ; // siguiente mensaje es de un productor
         else                                   rama = 1 ; // siguiente mensaje es de un consumidor
      }
      
      // recibir el siguiente mensaje
      switch( rama )
      {
         case 0 : 
            MPI_Recv( &buffer[pos], 1, MPI_INT, MPI_ANY_SOURCE, TAG_PROD, MPI_COMM_WORLD, &status );
            cout << "Buffer (en iteración " << i+1 << ") ha recibido " << buffer[pos] << " de Productor " << endl << flush;  
            pos++;
            break;
         case 1 : 
						MPI_Recv( &peticion, 1, MPI_INT, MPI_ANY_SOURCE, TAG_CONS, MPI_COMM_WORLD,&status);
           	MPI_Ssend( &buffer[pos-1], 1, MPI_INT, status.MPI_SOURCE, TAG_CONS,  MPI_COMM_WORLD );
            cout << "Buffer (en iteración " << i+1 <<  "), ha enviado " << buffer[pos-1] << " a Consumidor " << endl << flush;  
            pos--;
            break;
      }     
   }
   cout << "fin del buffer." << endl << flush ;
}   
// ---------------------------------------------------------------------

void dormir( double secs_min, double secs_max )
{
   static bool primera = true ;
   
   // inicializar generador de números aleatorios (la primera vez)
   if ( primera )
   {  srand(time(NULL)) ;
      primera = false ;
   }
   // retraso aleatorio, con el tiempo indicado
   const double millon = 1000000.0d ;
   const int usecs_min = int(secs_min*millon),
             usecs_max = int(secs_max*millon);
   usleep( usecs_min + ( rand() % (usecs_max-usecs_min) ) ); 
}
