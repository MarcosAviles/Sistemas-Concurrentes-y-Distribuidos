#include <iostream>
#include <pthread.h>
#include <semaphore.h>
using namespace std ;

const int num_items = 50; 		// Numero de items.
const int tam_vec = 10; 		// Tamaño del vector.


int primera_libre = 0;	// Indice del vector de la primera celda ocupada.

int buffer[tam_vec];   // Vector de items.

sem_t puede_leer, puede_escribir; //Variables tipo Semaforo


int producir_dato(){
	static int contador = 1 ;
	return contador ++ ;
}

void consumir_dato( int dato ){
	cout << "dato recibido: " << dato << endl;
}



void * productor( void * ){
	for( unsigned i = 0 ; i < num_items ; i++ ){
							
		 int dato = producir_dato() ;

		 sem_wait( &puede_escribir );
		 
		 buffer[primera_libre] = dato;
		 primera_libre++;

		 sem_post( &puede_leer );		 
	}
	return NULL ;
}


void * consumidor( void * ){
	for( unsigned i = 0 ; i < num_items ; i++ ){
		
			int dato ;
			sem_wait( &puede_leer );	

			dato = buffer[primera_libre-1];
			consumir_dato( dato ) ;
			primera_libre--;
			
			sem_post( &puede_escribir);
	}
	return NULL ;
}


int main(){

	for(int i=0; i<tam_vec; i++)
		buffer[i] = 0;								// Poner buffer a 0 (El buffer esta vacio)

	cout << "Tamaño del vector: " << tam_vec << endl;
	cout << "Numero de items: " << num_items << endl;

		sem_init( &puede_escribir, 0, tam_vec); // inicialmente se puede escribir tam_vec items
		sem_init( &puede_leer, 0, 0); // inicialmente no se puede leer


	pthread_t hebra_productora, hebra_consumidora;

	pthread_create( &hebra_productora, NULL, productor, NULL);
	pthread_create( &hebra_consumidora, NULL, consumidor, NULL);

	pthread_join( hebra_productora, NULL ) ;
	pthread_join( hebra_consumidora, NULL ) ;
	cout << "Fin." << endl;

	sem_destroy( &puede_escribir );  // Destruir los semaforos.
	sem_destroy( &puede_leer );

}
