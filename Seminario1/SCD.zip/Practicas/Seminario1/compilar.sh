#!/bin/bash

gcc -g -c fun_tiempo.c # compila ”fun tiempos.c” y genera ”fun tiempos.o”
g++ -g -c pi_sec_conc.cpp # compila ”ejemplo.cpp” y genera ”ejemplo.o”
g++ -o pi_sec_conc pi_sec_conc.o fun_tiempo.o -lrt -lpthread # enlaza, genera ”ejemplo”
