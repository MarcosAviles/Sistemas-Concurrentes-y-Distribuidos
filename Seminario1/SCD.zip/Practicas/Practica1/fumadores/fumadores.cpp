#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>// incluye ”time(....)”
#include <unistd.h> // incluye ”usleep(...)”
#include <stdlib.h> // incluye ”rand(...)” y ”srand”

using namespace std ;


sem_t puede_fumar0, puede_fumar1, puede_fumar2, produce_estanquero; //Variables tipo Semaforo


// funcion que simula la accion de fumar como un retardo aleatorio de la hebra

void fumar(){ 
	// calcular un numero aleatorio de milisegundos (entre 1/10 y 2 segundos)
	const unsigned miliseg = 100U + (rand() % 1900U) ;
	usleep( 1000U*miliseg ); // retraso bloqueado durante miliseg milisegundos
}

//Fumador0 tiene tabaco y cerilllas le falta el papel.
//Fumador1 tiene papel y ceriilas le falta el tabaco.
//Fumador2 tiene papel y tabaco le falta ceriilas.

//Funcion Estanquero
void * Estanquero(void *i){

	while(true){

		sem_wait(&produce_estanquero);

		int ingrediente = rand() % 3; //Produce el ingrediente (0 = papel), (1 = tabaco) y (2 = cerillas)

		

		if( ingrediente == 0 ){
			cout << "Estanquero: He producido el ingrediente " << ingrediente << endl;
			sem_post(&puede_fumar0);
		} 
		if( ingrediente == 1 )
		{	
			cout << "Estanquero: He producido el ingrediente " << ingrediente << endl;	
			sem_post(&puede_fumar1);
				
		}
		if( ingrediente == 2 )
		{
			cout << "Estanquero: He producido el ingrediente " << ingrediente << endl;
			sem_post(&puede_fumar2);
		}
	}
	return NULL;
}

//Funcione fumadores
void * fumadores( void * i){
	
		unsigned long fumador = (unsigned long)i;

	while (true){
			if (fumador == 0){
					sem_wait (&puede_fumar0);
					cout << "Fumador0 tiene los 3 ingredientes y se pone a fumar. " << endl;
					sem_post(&produce_estanquero);
					fumar();
					cout << "Fumador0 ha terminado de fumar. " << endl;
			}
			if (fumador == 1){
					sem_wait (&puede_fumar1);
					cout << "Fumador1 tiene los 3 ingredientes y se pone a fumar. " << endl;
					sem_post(&produce_estanquero);				
					fumar();
					cout << "Fumador1 ha terminado de fumar. " << endl;
			}
			if (fumador == 2){
					sem_wait (&puede_fumar2);
					cout << "Fumador2 tiene los 3 ingredientes y se pone a fumar. " << endl;
					sem_post(&produce_estanquero);
					fumar();
					cout << "Fumador2 ha terminado de  fumar. " << endl;
			}
	}
	return NULL;
}



int main(){

	srand( time(NULL) ); // inicializa la semilla aleatoria

	sem_init( &puede_fumar0, 0, 0); 
	sem_init( &puede_fumar1, 0, 0); 
	sem_init( &puede_fumar2, 0, 0); 
	sem_init( &produce_estanquero, 0, 1); 
		

	pthread_t fumador0, fumador1, fumador2, estanquero;

	pthread_create( &fumador0, NULL, fumadores,(void *)0);
	pthread_create( &fumador1, NULL, fumadores, (void *)1);
	pthread_create( &fumador2, NULL, fumadores, (void *)2);
	pthread_create( &estanquero, NULL, Estanquero, NULL);

	pthread_join( fumador0, NULL ) ;
	pthread_join( fumador1, NULL ) ;
	pthread_join( fumador2, NULL ) ;
	pthread_join( estanquero, NULL ) ;

	sem_destroy( &puede_fumar0 );  // Destruir los semaforos.
	sem_destroy( &puede_fumar1 );
	sem_destroy( &puede_fumar2 );
	sem_destroy( &produce_estanquero );
}


