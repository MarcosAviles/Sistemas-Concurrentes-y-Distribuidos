import monitor.*;
import monitor.AbstractMonitor;
import monitor.Condition;

//MONITOR
class Buffer extends AbstractMonitor { 

	private int numSlots = 0, cont = 0;   
  private double[] buffer = null; //Buffer
	private Condition lectura = makeCondition();//condicion de lectura
  private Condition escritura = makeCondition();//condicion de escritura

	//Constructor
  public Buffer( int p_numSlots ) { 
		numSlots = p_numSlots ; 
    buffer = new double[numSlots] ;
  }

	//metodo productor
  public void depositar( double valor ) { 
	enter();
  /*mientras el buffer no esté lleno escribimos datos en él. En caso
   * contrario dormimos hasta que se quede libre el buffer.*/
   	if( cont == numSlots ) 
			escritura.await();
              
    buffer[cont] = valor; 
		cont++; //guardamos el valor en el indice cont.     
    lectura.signal();/*si está dormida la funcion de lectura por no tener 
     * datos la despertamos para que pueda leer.
     */
    leave();
  }

	 //metodo consumidor
  public  double extraer()  { 
		enter();
    double valor;
  	/*mientras el buffer tenga datos leemos en él. En caso
   			contrario dormimos hasta que tengamos datos que leer eb el buffer.*/
    if( cont == 0 ) 
			lectura.await() ;

    cont--; 
		valor = buffer[cont] ;
    escritura.signal();/*si está dormida la funcion de escritura por no tener 
     * sitio para escribir la despertamos para que pueda escribir.
     */
    leave();
    return valor;
  }
}


//Hebra Productora
class Productor implements Runnable { 
	private Buffer bb ;
  int veces; 
  int numP ;
  Thread thr ;

	//Constructor
  public Productor( Buffer pbb, int pveces, int pnumP ) { 
		bb    = pbb;
    veces = pveces;
    numP  = pnumP ;
    thr   = new Thread(this,"productor "+numP);
  }

  public void run() { 
		try{ 
			double item = 100*numP ;
      for( int i=0 ; i<veces ; i++ ){ 
				System.out.println(thr.getName()+", produciendo " + item);
        bb.depositar( item++ );
      }
    }
    catch( Exception e ) { 
			System.err.println("Excepcion en main: " + e);
    }
  }
}



//Hebra Consumidora
class Consumidor implements Runnable { 
	private Buffer bb ;
  int veces; 
  int numC ;
  Thread thr ;
	
	//Constructor
  public Consumidor( Buffer pbb, int pveces, int pnumC ) { 
		bb    = pbb;
    veces = pveces;
    numC  = pnumC ;
    thr   = new Thread(this,"consumidor "+numC);
  }

  public void run() { 
		try { 
			for( int i=0 ; i<veces ; i++ ){ 
				double item = bb.extraer ();
        System.out.println(thr.getName()+", consumiendo "+item);
      } 
    }
    catch( Exception e ) { 
			System.err.println("Excepcion en main: " + e);
    }
  }
}



//MAIN
class procon { 
	public static void main( String[] args ) { 
		if ( args.length != 5 ) {  
			 System.err.println("Uso: numconsumidores numprodudctores tambuffer niterp niterc");
       return ;
    }

    // leer parametros, crear vectores y buffer intermedio
    Consumidor[] cons = new Consumidor[Integer.parseInt(args[0])] ;
	  Productor[]  prod = new Productor[Integer.parseInt(args[1])] ;
	  Buffer buffer = new Buffer(Integer.parseInt(args[2])); //Objeto del monitor
	  int iter_cons = Integer.parseInt(args[3]);
	  int iter_prod = Integer.parseInt(args[4]);

	  if ( cons.length*iter_cons != prod.length*iter_prod ){ 
			System.err.println("no coinciden número de items a producir con a cosumir");
      return ;
    }   
 
	  // crear hebras
	  for(int i = 0; i < cons.length; i++) 
	    cons[i] = new Consumidor(buffer,iter_cons,i) ;

	  for(int i = 0; i < prod.length; i++)
	    prod[i] = new Productor(buffer,iter_prod,i) ;

	  // lanzar hebras
	  for(int i = 0; i < prod.length; i++) 
				prod[i].thr.start();

	  for(int i = 0; i < cons.length; i++) 
				cons[i].thr.start();
  }
}

