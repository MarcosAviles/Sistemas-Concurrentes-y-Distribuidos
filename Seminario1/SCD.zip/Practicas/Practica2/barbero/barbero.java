import monitor.*;
import monitor.AbstractMonitor;
import monitor.Condition;
import java.util.Random;


//Clase auxiliar
class aux{

	static Random genAlea = new Random() ;
	static void dormir_max( int milisecsMax ){ 
		try{ 
			Thread.sleep( genAlea.nextInt( milisecsMax ) ) ;
		}	
		catch( InterruptedException e ){ 
			System.err.println("sleep interumpido en ’aux.dormir_max()’");
		}
	}
}


//Monitor
class Barberia extends AbstractMonitor{
	// private int num_clientes = 5;
	
	 boolean silla_cortar;// Nos indica si el barbero esta ocupado pelando a un cliente.
	 boolean pelando; // Nos indica cuando esta el barbero pelando.
	 int sala_espera; //Clientes que hay para pelarse.

	 Condition barbero;//Condicion para el barbero.
   Condition colaclientes;//Condicion para cada cliente.
	 Condition silla; //Condicion para para la silla de cortar.
	
		 //Constructor
    public Barberia() {
			silla_cortar = false;
			pelando = false; 
			sala_espera = 0;
			silla = makeCondition();
      barbero = makeCondition();
      colaclientes = makeCondition();      
    }


	// invcado por los clientes para cortarse el pelo
	public void cortarPelo (int idCliente){
		 enter();
		 sala_espera++;
		 System.out.println("Cliente "+idCliente+ " entra en la barberia.");	

		 if (silla_cortar) //Si la silla esta ocupada el clliente debe esperar.
				colaclientes.await();

		 System.out.println("El barbero esta pelando al cliente " + idCliente);	
		 barbero.signal(); // Despertamos al barbero
		 silla_cortar = true; // La silla esta ocupada

		 if (pelando)  // Mientras esta pelando
				silla.await(); // Hay que esperar a que termine de pelar.

 		 System.out.println("El cliente "+idCliente+" ha terminado.");
		 sala_espera--;	 // Un Cliente menos
		 leave();			
	}

	// invocado por el barbero para esperar (si procede) a un nuevo cliente y sentarlo para el corte
	public void siguienteCliente (){ 
			enter();
			if (sala_espera == 0) //El barbero espera si no hay clientes
				barbero.await();

			colaclientes.signal(); // Un cliente ya puede pasar a pelarse.
			leave();
	}

	// invocado por el barbero para indicar que ha terminado de cortar el pelo,
	public void finCliente (){ 
			 enter();
        silla_cortar = false;//Dejamos la silla libre.
				pelando = false;  // No estamos pelando.
				silla.signal();   //Se termina de pelar al cliente.
			 leave();
	}
}


//Hebra Cliente
class Cliente implements Runnable{ 

	public Thread thr ;
	Barberia barberia;	
	int idCliente;	

		//Constructor
		public Cliente(int cliente, Barberia e ) {
        thr= new Thread (this,"Hebra Cliente "+idCliente);
        idCliente = cliente;//Cliente
        barberia=e;//monitor
    }

		public void run (){ 
			while (true) {
				barberia.cortarPelo (idCliente); // el cliente espera (si procede) y se corta el pelo
				aux.dormir_max( 2000 ); // el cliente esta fuera de la barberia un tiempo
			}
		}
}


//Hebra Barbero
class Barbero implements Runnable{ 

	public Thread thr ;
	Barberia barberia;

	//Constructor
	public Barbero (Barberia e){
		barberia = e;
		thr= new Thread (this,"Hebra Barbero");
	}
	
	public void run (){ 
		while (true) {
			barberia.siguienteCliente ();
			aux.dormir_max( 2500 ); // el barbero esta cortando el pelo
			barberia.finCliente ();
		}
	}
}

//MAIN
class Barberia_java { 
	public static void main(String[] args) {
	
	Barberia barberia = new Barberia();//Creancion del monitor.

	//Cracion de hebras.
	Barbero barbero = new Barbero(barberia); // Barbero
	Cliente[] clientes = new Cliente[3]; //Clientes
	for (int i=0; i<3; i++)
			clientes[i] = new Cliente(i,barberia);

	//Lanzamiento de hebras.
	barbero.thr.start();
	for (int i=0; i<3; i++)
			clientes[i].thr.start();

	}
} 


