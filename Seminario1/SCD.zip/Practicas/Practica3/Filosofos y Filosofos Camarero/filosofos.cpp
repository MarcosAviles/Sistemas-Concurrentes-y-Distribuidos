#include "mpi.h"
#include <iostream>
#include <time.h>
#include <stdlib.h>

using namespace std;

#define CojerTenedor 0
#define SoltarTenedor 1


//Funcion Filosofo
void Filosofo(int id, int nprocesos){
 int izq=(id+1)%nprocesos;
 int der=(id-1+nprocesos)%nprocesos; 
  
 while(1){
	if (id == 0){ // Si id es el proceso 0 que coja primero el tenedor derecho para evitar que
			//todos cojan primero el tenedor izquierdo

		//Solicita tenedor derecho
	  cout<<"Filosofo "<<id<< " coge tenedor der ..."<<der <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, der, CojerTenedor, MPI_COMM_WORLD); //peticion para cojer el tenedor der tag 0

		//Solicita tenedor izquierdo
	  cout<<"Filosofo "<<id<< " solicita tenedor izq ..."<<izq <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, izq, CojerTenedor, MPI_COMM_WORLD); //peticion para cojer al tenedor izq tag 0
	} else {

  	//Solicita tenedor izquierdo
  	cout<<"Filosofo "<<id<< " solicita tenedor izq ..."<<izq <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, izq, CojerTenedor, MPI_COMM_WORLD); //peticion para cojer al tenedor izq tag 0
  
  	//Solicita tenedor derecho
  	cout<<"Filosofo "<<id<< " coge tenedor der ..."<<der <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, der, CojerTenedor, MPI_COMM_WORLD); //peticion para cojer el tenedor der tag 0
	
  	cout<<"Filosofo "<<id<< " COMIENDO"<<endl<<flush;
  	sleep((rand() % 3)+1);  //comiendo
	}

  //suelta el tenedor izquierdo
  cout<<"Filosofo "<<id<< " suelta tenedor izq ..."<<izq <<endl<<flush;
  MPI_Ssend(&id, 1, MPI_INT, izq, SoltarTenedor, MPI_COMM_WORLD); //Soltamos el tenedor izq tag 1

  //suelta el tenedor derecho
  cout<<"Filosofo "<<id<< " suelta tenedor der ..."<<der <<endl<<flush;
	MPI_Ssend(&id, 1, MPI_INT, der, SoltarTenedor, MPI_COMM_WORLD); //Soltamos el tenedor der tag 1

  cout<<"Filosofo "<<id<< " PENSANDO"<<endl<<flush;
  sleep((rand()%3)+1 );//pensando
 }
}

//Funcion Tenedor
void Tenedor(int id, int nprocesos){
  int buf, Filo;
  MPI_Status status; 

  while(1){
    // Espera un peticion desde cualquier filosofo vecino ...
		
    // Recibe la peticion del filosofo ...
		MPI_Recv( &Filo, 1, MPI_INT, MPI_ANY_SOURCE, CojerTenedor, MPI_COMM_WORLD,&status); 
		//Esperamos cualquier peticion de cojer tenedor y cargamos status del filosofo que es.   
		cout<<"Ten. "<<id<<" recibe petic. de "<<Filo<<endl<<flush;
    
		// Espera a que el filosofo suelte el tenedor...
    MPI_Recv( &buf, 1, MPI_INT, status.MPI_SOURCE, SoltarTenedor, MPI_COMM_WORLD,&status);  
		//Utilizamos status por que el mismo filosofo que coje el tenedero debe sortarlo.  
    cout<<"Ten. "<<id<<" recibe liberac. de "<<Filo<<endl<<flush; 
  }
}



int main(int argc,char** argv ){
 int rank,size;
 srand(time(0));

 MPI_Init( &argc, &argv );
 MPI_Comm_rank( MPI_COMM_WORLD, &rank );
 MPI_Comm_size( MPI_COMM_WORLD, &size );

 if( size!=10){
   if(rank == 0) 
      cout<<"El numero de procesos debe ser 10"<<endl<<flush;
   MPI_Finalize( ); return 0; 
 }

 if ((rank%2) == 0)  
    Filosofo(rank,size); // Los pares son Filosofos 
 else 
		Tenedor(rank,size);  // Los impares son Tenedores 

 MPI_Finalize( );

 return 0;
}  


