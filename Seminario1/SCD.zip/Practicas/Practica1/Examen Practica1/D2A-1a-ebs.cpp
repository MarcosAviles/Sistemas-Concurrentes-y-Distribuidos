// Prácticas de SCD - Curso 2014-15
// Práctica 1 - prueba de evaluación
// Grupo D2 (Jueves 15:30-17:30) 
// Prueba tipo A
// Ejercicio 1 - incluye error básico y de sincronización

#include <iostream>  // incluye 'std::cout'
#include <stdlib.h>  // incluye 'rand' y 'srand'
#include <unistd.h>  // incluye 'usleep( <millonésimas-de-segundo> )'
#include <time.h>    // incluye 'time' 
#include <pthread.h>
#include <semaphore.h>

using namespace std ;

const unsigned 
   num_items = 30 , 
   tam_vec   = 5  ;
int 
   vector[tam_vec] ;
unsigned 
   primera_libre   = 0,
   primera_ocupada = 0;
pthread_t 
   hebra_productor, 
   hebra_consumidor ;
sem_t 
	puede_escribir, 
	puede_leer,
	mutex ;

//----------------------------------------------------------------------

int producir_dato()
{
   static int contador = 1 ;
   usleep( 1000UL*( 20UL+(rand()%80UL) ) ) ;
   return contador ++ ;
}

//----------------------------------------------------------------------

void consumir_dato( int dato )
{
   sem_wait( &mutex );
   cout << "consumiendo dato: " << dato << endl ;
   sem_post( &mutex ) ;
   usleep( 1000UL*( 20UL+ (rand()%80UL) ) );
}

//----------------------------------------------------------------------

void * funcion_productor( void * )
{  
   int dato ;
   
   for( unsigned i = 0 ; i < num_items ; i++ )
   {  
      dato = producir_dato() ;
      sem_wait( &puede_escribir ) ;
      vector[primera_libre] = dato ;
      primera_libre = (primera_libre + 1) % tam_vec ;	
      sem_post( &puede_leer ) ;
   }
}

//----------------------------------------------------------------------

void * funcion_consumidor( void * )
{
   int dato ;
   
   for( unsigned i = 0 ; i < num_items ; i++ )
   {   
      sem_wait( &puede_leer );
      dato = vector[primera_ocupada] ;
      primera_ocupada = (primera_ocupada + 1) % tam_vec ;    
      consumir_dato( dato ) ;
		
   }
}

//----------------------------------------------------------------------

int main()
{
   srand( time(NULL) );
   
   sem_init( &puede_escribir, 0, tam_vec); 
   sem_init( &puede_leer, 0, 0); 
   sem_init( &mutex, 0, 1 ) ;  

   pthread_create( &hebra_productor, NULL, NULL, funcion_productor,  );
   pthread_create( &hebra_consumidor, NULL, NULL, funcion_consumidor,  );
   
   pthread_join( hebra_productor,  NULL ) ;
   pthread_join( hebra_consumidor, NULL ) ;

   sem_destroy( &puede_escribir );
   sem_destroy( &puede_leer ); 
}


