import monitor.* ;
import java.util.Random ;

class auxb
{
   static Random genAlea = new Random() ;
   static void dormir_max( int milisecsMax )
   {  try
      { Thread.sleep( genAlea.nextInt( 200+milisecsMax ) ) ;
      } 
      catch( InterruptedException e )
      { System.err.println("sleep interumpido en 'aux.dormir_max()'");
      }
   }
   static public void mensaje( String str )
   {
      System.out.println( Thread.currentThread().getName()+": "+str);
   }
}
class Barberia extends AbstractMonitor
{
   Condition clientesEnEspera, 
             clienteEnCorte ;
   int       barberoDormido ; 
             
   public Barberia()
   {
      clientesEnEspera = makeCondition() ;
      clienteEnCorte  = makeCondition() ;
      barberoDormido  = makeCondition() ;
   }
   public void cortarPelo()
   {
      enter() ;
      auxb.mensaje("llega a la barberia.");
      if ( barberoDormido.isEmpty() ) 
         clientesEnEspera.await() ; 
      auxb.mensaje("comienza a cortarse el pelo.");
      clienteEnCorte.await() ;
      auxb.mensaje("ha terminado de cortarse el pelo, abandona la barbería.");
      leave() ;
   }
   public void siguienteCliente()
   {
      enter() ;
      auxb.mensaje("siguiente cliente.");
      if ( clientesEnEspera.isEmpty() ) 
         barberoDormido.await() ; 
      else 
         clientesEnEspera.signal() ;
      auxb.mensaje("comienza a cortar el pelo");
      leave() ;
   }
   public void finCliente()
   {
      enter() ;
      auxb.mensaje("finaliza corte de pelo, indicará al cliente que salga");
      clienteEnCorte.signal() ; 
      leave() ;	   
   }
}
class Cliente implements Runnable
{
   private Barberia    barberia ;
   public  Thread      thr ;
   
   public Cliente( Barberia p_barberia, int p_contador )
   {
      barberia = p_barberia ;
      thr      = new Thread(this,"cliente "+p_contador);
   }
   public void run()
   {
      while( true )
      {
         barberia.cortarPelo() ;
         auxb.dormir_max( 10000 ) ;
      }
   }
}
class Barbero implements Runnable
{
   Barberia       barberia ;
   public Thread  thr ;
   
   public Barbero( Barberia p_barberia )
   {
      barberia = p_barberia ;
      thr      = new Thread(this,"barbero");
   }
   public void run()
   {
      while( true )
      {
         barberia.siguienteCliente() ;
         auxb.dormir_max( 1000 );
         barberia.finCliente() ;
      }
   }
}
class A1es
{
   public static void main( String args[] ) throws InterruptedException 
   {
      System.out.println("comienza simulación de barbería.");
      
      int num_cli = 5 ;
      
      Barberia  barberia = new Barberia() ;
      Barbero   barbero  = new Barbero(barberia);
      Cliente[] cliente  = new Cliente[num_cli] ;
      
      for( int i = 0 ; i < num_cli ; i++ )
        cliente[i] = new Cliente(barberia,i) ;
        
      barbero.thr.start() ;
      for( int i = 0 ; i < num_cli ; i++ )
        cliente[i].thr.start() ;
        
      barbero.thr.join() ;
      for( int i = 0 ; i < num_cli ; i++ )
         cliente[i].thr.join() ;
         
      System.out.println("simulación de barbería finalizada normalmente.");
   }
}
