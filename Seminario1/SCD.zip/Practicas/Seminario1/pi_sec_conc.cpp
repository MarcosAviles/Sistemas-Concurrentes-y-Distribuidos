#include <iostream>
#include <pthread.h>
#include "fun_tiempo.h"
#include "stdlib.h"
#include <vector>


using namespace std ;

unsigned long m;  // número de muestras 
unsigned n;      // número de hebras
vector<double> resultado_parcial;


double f( double x )       // implementa función $f$
{ 
   return 4.0/(1+x*x) ;     // $~~~~f(x)\,=\,4/(1+x^2)$
}

double calcular_integral_secuencial( )
{  
   double suma = 0.0 ;                      // inicializar suma
   for( unsigned long i = 0 ; i < m ; i++ ){// para cada $i$ entre $0$ y $m-1$
      suma += f( (i+0.5)/m );               // $~~~~~$ añadir $f(x_i)$ a la suma actual
   }	
   return suma/m ;                          // devolver valor promedio de $f$
}


void * funcion_hebra( void * ih_void) // función que ejecuta cada hebra
{  
   unsigned long ih = (unsigned long) ih_void ; // número o índice de esta hebra
   double sumap = 0.0 ;
   // calcular suma parcial en "sumap"
   for (unsigned long i = ih*m/n; i<ih*m/n+m/n; i++)
       sumap += f((i+0.5)/m);
   
   resultado_parcial[ih] = sumap ; // guardar suma parcial en vector.
   return NULL ;
}

double calcular_integral_concurrente(){
	double suma_total;

   // crear y lanzar $n$ hebras, cada una ejecuta "funcion\_concurrente"
   
	pthread_t id_hebra[n];
	for( unsigned i = 0 ; i < n ; i++ )
		pthread_create( &(id_hebra[i]), NULL, funcion_hebra, (void *)i);

   // esperar (join) a que termine cada hebra, sumar su resultado
  
	for( unsigned i = 0 ; i < n ; i++ ){
		pthread_join( id_hebra[i], NULL);
		suma_total += resultado_parcial[i];
	}
   // devolver resultado completo
   return suma_total/m;
}

void sintaxis()
{
  cerr << "Sintaxis:" << endl;
  cerr << "  m: Numero de muestras" << endl;
  cerr << "  n: Numero de hebras" << endl;
  cerr << " m debe ser multiplo de n " << endl;
  exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]){

	 if (argc!=3)
    	sintaxis();

	m = atoi(argv[1]);
	n = atoi(argv[2]);
	resultado_parcial.resize(n);

   cout << "Ejemplo 4 (cálculo de PI)" << endl;
   cout << "Valor PI exacto: 3.141592" << endl;
   struct timespec inicios = ahora() ;
   cout << "valor de PI (calculado secuencialmente) == " << calcular_integral_secuencial() << endl; 
   struct timespec fins = ahora() ;
	
   struct timespec inicioc = ahora() ;
   cout << "valor de PI (calculado concurrentemente) == " << calcular_integral_concurrente() << endl << endl ; 
   struct timespec finc = ahora() ;

   cout << "Tiempo calculo secuencial: " << duracion(&inicios, &fins) << " segundos." << endl;
   cout << "Tiempo calculo concurrente: " << duracion(&inicioc, &finc) <<  " segundos." << endl;
}


