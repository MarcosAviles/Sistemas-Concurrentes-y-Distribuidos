import monitor.*;
import monitor.AbstractMonitor;
import monitor.Condition;
import java.util.Random;


//Monitor
class Estanco extends AbstractMonitor { 
    
		boolean hayingredientes = false; //boleana para comprobar que hay ingredientes en la mesa.
    int ingrediente_creado = -1;   //Tipo de ingrediente. (0,1,2).

    Condition estanquero;//condicion para el estanquero
    Condition colafumador[] = new Condition[3];//condicion para cada uno de los fumadores

		//Constructor
    public Estanco(){
			hayingredientes = false;
			ingrediente_creado = -1;
			estanquero = makeCondition();
			for (int i = 0; i < 3; i++) {
        colafumador[i] = makeCondition();//creamos la condicion
      }
		}
   
    //invocado por cada fumador, indicando su ingrediente o numero
		//Recoje el ingrediente.
    public void obtenerIngredientes(int miIngrediente) {
        enter();
        if (!hayingredientes || ingrediente_creado != miIngrediente) {//mientra no 
         //sea el ingrediente correspondiente al fumador, este espera en la cola
         colafumador[miIngrediente].await();
        }
        System.out.println("Fumando el fumador " + miIngrediente);
        hayingredientes = false;//recogemos el ingrediente y fuma
        estanquero.signal();//hacemos signal para despertar al estanquero
				System.out.println("El fumador " + miIngrediente + " ha terminado de fumar.");
        leave();
		}        	
    
    // invocado por el estanquero, indicando el ingrediente que pone
    public void ponerIngredientes(int ingrediente) {
        enter();
				if (hayingredientes) //Si hay ingredientes el estanquero espera.
						estanquero.await();

				hayingredientes = true;
        ingrediente_creado = ingrediente;//ingrediente creado
				System.out.println("Ingrediente producido: "+ingrediente);
        colafumador[ingrediente].signal();//despertamos al fumador que corresponda con su ingrediente.
        leave();
    }

   // invocado por el estanquero
    public void esperarRecogidaIngredientes() {
        enter();
       		if (hayingredientes) //Si hay ingredientes el estanquero espera.
							estanquero.await();
				leave();
    }
}

class Fumador implements Runnable {

    private Estanco estanco;//monitor
    int miIngrediente;//numero ingrediente
    public Thread thr;//hebra

    //Constructor
    public Fumador(int miIngre,Estanco e ) {
        thr= new Thread (this,"Hebra fumador "+miIngre);
        miIngrediente=miIngre;//ingrediente == idHebra
        estanco=e;//monitor
    }

    public void run() {
        while (true) {
            estanco.obtenerIngredientes(miIngrediente);//llamada para obtener ingrediente
            try {
                //tiempo que espera la hebra dormida
                Thread.sleep(2000);
            } catch (InterruptedException e) {
            }
        }
    }
}

class Estanquero implements Runnable { 
    public Thread thr ;//hebra
    private Estanco estanco;//monitor

    //Constructor
    public Estanquero(Estanco e){
        estanco=e;//monitor
        thr= new Thread (this,"Hebra Estanquero");
    } 
   
    public void run() { 
        int ingrediente;
        while (true){ 
            ingrediente = (int) (Math.random () * 3.0);//ingrediente creado 0..2
            estanco.ponerIngredientes( ingrediente);//metodo monitor para poner ingrediente
            estanco.esperarRecogidaIngredientes() ;//metodo que espera que se recoja el ingrediente             
        }
    }
}

//MAIN
class Fumadores { 
	public static void main(String[] args) {

	Estanco estanco = new Estanco();//Creancion del monitor.

	//Cracion de hebras.
	Estanquero estanquero = new Estanquero(estanco);
	Fumador[] hfumadoras = new Fumador[3];
	for (int i=0; i<3; i++)
			hfumadoras[i] = new Fumador(i,estanco);

	//Lanzamiento de hebras.
	estanquero.thr.start();
	for (int i=0; i<3; i++)
			hfumadoras[i].thr.start();

	}
} 


