#include "mpi.h"
#include <iostream>
#include "math.h"
#include <time.h>
#include <stdlib.h>

#define TAM 10
#define ITERS 20
#define Buffer 5
#define Productor 0
#define Consumidor 1

using namespace std;

//Funcion Productor
void productor(){  
for (unsigned int i=0;i<ITERS/5;i++){ 
  cout<< "Productor produce valor "<<i<<endl<<flush;
  sleep(rand() % 2 );
  MPI_Ssend( &i, 1, MPI_INT, Buffer, Productor, MPI_COMM_WORLD );//Mandamos al buffer el dato generado
 }
}

//Funcion Buffer
void buffer(){
 int value[TAM], peticion, pos=0,rama;

 MPI_Status status;

 for (unsigned int i=0;i<ITERS*2;i++){  
   if (pos==0) 
	rama=0;        //El consumidor no puede consumir
   else if (pos==TAM) 
	  rama=1; // El productor no puede producir   
   	else{  //Ambas guardas son ciertas
     	  MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);//vemos quien es el que nos esta dando una peticion 
      	    if (status.MPI_SOURCE < Buffer) 
		rama =0; //si status tiene un proceso menor que buffer es que es un productor y entramos en rama 0 para atenderle
	    else rama=1; //si status tiene un proceso mayor que buffer es que es un consumidor y entramos en rama 1 para atenderle
   	}

   switch(rama){
     case 0://Productor
       MPI_Recv( &value[pos], 1, MPI_INT, MPI_ANY_SOURCE, Productor, MPI_COMM_WORLD, &status); 
		//recibimos de cualquier source pero solo del tag 0 que son los productores 	
       cout<< "Buffer recibe "<< value[pos] << " de Productor "<<endl<<flush;  
       pos++;
       break;

     case 1://Consumidor
       MPI_Recv( &peticion, 1, MPI_INT, MPI_ANY_SOURCE, Consumidor, MPI_COMM_WORLD,&status);
	//recibimos de cualquier source pero solo del tag 1 que son los consumidores pidiendo un dato
       MPI_Ssend( &value[pos-1], 1, MPI_INT, status.MPI_SOURCE, Consumidor, MPI_COMM_WORLD); //cuando ya se ha recibido la peticion
       //se envia el dato con tag 1 para los consumidores y al source del que habíamos recibido la peticion
       cout<< "Buffer envía "<< value[pos-1] << " a Consumidor "<<endl<<flush;  
       pos--;
       break;
   }     
 }
}   
   
//Funcion Consumidor     
void consumidor(){
 int value,peticion=1; float raiz;

 MPI_Status status;

 for (unsigned int i=0;i<ITERS/4;i++){

  MPI_Ssend(&peticion, 1, MPI_INT, Buffer, Consumidor, MPI_COMM_WORLD); //se envia una peticion de dato al buffer con tag 1
  MPI_Recv(&value, 1, MPI_INT, Buffer, Consumidor, MPI_COMM_WORLD,&status ); //se recibe el valor

  cout<< "Consumidor recibe valor "<<value<<" de Buffer "<<endl<<flush;
  sleep(rand() % 2 );
  raiz=sqrt(value);
 }
}


int main(int argc, char *argv[]) {
  int rank,size; 
  cout.flush();

  MPI_Init( &argc, &argv ); //Inicializa mpi

  MPI_Comm_rank( MPI_COMM_WORLD, &rank ); // En rank se guarda el numero de proceso que se esta ejecutando
  MPI_Comm_size( MPI_COMM_WORLD, &size ); // En size se guarda el numero de procesos del comunicador

  /* Inicializa la semilla aleatoria */
		srand ( time(NULL) );

	
  if (size!=10) 
   {cout<< "El numero de procesos debe ser 10 "<<endl;return 0;} 
 
	 if (rank < Buffer) 
			productor();
   else if (rank==Buffer) 
					buffer();
    		else 
					consumidor();

  MPI_Finalize( ); // Finaliza mpi

  return 0;
}

