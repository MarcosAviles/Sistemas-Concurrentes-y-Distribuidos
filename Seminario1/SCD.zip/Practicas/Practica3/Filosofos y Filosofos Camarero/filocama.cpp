#include "mpi.h"
#include <iostream>
#include <time.h>
#include "math.h"
#include <stdlib.h>

using namespace std;

#define Levantarse 3
#define Sentarse 2
#define CojerTenedor 0
#define SoltarTenedor 1
#define Cama_rero 10

//Funcion Filosofo
void Filosofo(int id, int nprocesos){
  int izq=(id+1)%nprocesos;
  int der=(id-1+nprocesos)%nprocesos;

 while(1){
		//Solicita al camarero sentarse
		cout<<"Se han sentado en la mesa el Filosofo " << id <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, Cama_rero, Sentarse, MPI_COMM_WORLD);
		 		
  	//Solicita tenedor izquierdo
  	cout<<"Filosofo "<<id<< " solicita tenedor izq ..."<<izq <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, izq, CojerTenedor, MPI_COMM_WORLD); //peticion para cojer al tenedor izq 
  
  	//Solicita tenedor derecho
  	cout<<"Filosofo "<<id<< " coge tenedor der ..."<<der <<endl<<flush;
		MPI_Ssend(&id, 1, MPI_INT, der, CojerTenedor, MPI_COMM_WORLD); //peticion para cojer el tenedor der 
	
  	cout<<"Filosofo "<<id<< " COMIENDO"<<endl<<flush;
  	sleep((rand() % 3)+1);  //comiendo
	

  //suelta el tenedor izquierdo
  cout<<"Filosofo "<<id<< " suelta tenedor izq ..."<<izq <<endl<<flush;
  MPI_Ssend(&id, 1, MPI_INT, izq, SoltarTenedor, MPI_COMM_WORLD); //Soltamos el tenedor izq 

  //suelta el tenedor derecho
  cout<<"Filosofo "<<id<< " suelta tenedor der ..."<<der <<endl<<flush;
	MPI_Ssend(&id, 1, MPI_INT, der, SoltarTenedor, MPI_COMM_WORLD); //Soltamos el tenedor der

	//Peticion para leventarse de la mesa
	cout<<"Se han levantado de la mesa el Filosofo " << id <<endl<<flush;
	MPI_Ssend(&id, 1, MPI_INT, Cama_rero, Levantarse, MPI_COMM_WORLD);

  cout<<"Filosofo "<<id<< " PENSANDO"<<endl<<flush;
  sleep((rand()%3)+1 );//pensando
 }
}

//Funcion Tenedor
void Tenedor(int id, int nprocesos){
  int buf, Filo;
  MPI_Status status; 

  while(1){
    // Espera un peticion desde cualquier filosofo vecino ...	
    // Recibe la peticion del filosofo ...

		//Esperamos cualquier peticion de cojer tenedor y cargamos status del filosofo que es.
		MPI_Recv( &Filo, 1, MPI_INT, MPI_ANY_SOURCE, CojerTenedor, MPI_COMM_WORLD,&status); 		   
		cout<<"Ten. "<<id<<" recibe petic. de "<<Filo<<endl<<flush;
    
		// Espera a que el filosofo suelte el tenedor...
		//Utilizamos status por que el mismo filosofo que coje el tenedero debe sortarlo.
    MPI_Recv( &buf, 1, MPI_INT, status.MPI_SOURCE, SoltarTenedor, MPI_COMM_WORLD,&status);  		  
    cout<<"Ten. "<<id<<" recibe liberac. de "<<Filo<<endl<<flush; 
  }
}

//Funcion Camarero
void Camarero(){

	int nsentados = 0, Filo; //Controla el numero de filosofos que hay sentados
	MPI_Status status; 

	while(1){
		if (nsentados < 4)//Si hay sitio para sentarse esperamos una peticion de Sentarse o de Levantarse
			MPI_Recv( &Filo, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,&status); 
		else {//Si no se puede sentar, esperamos hasta recibir una peticion de Levantarse
			MPI_Recv( &Filo, 1, MPI_INT, MPI_ANY_SOURCE, Levantarse, MPI_COMM_WORLD,&status); 
	  }

		if(status.MPI_TAG == Sentarse){
			// Recibe la peticion del filosofo para sentarse	
			nsentados++;
			cout<<"Camarero recibe una penticion para sentarse, hay "<< nsentados <<" filosofos sentados."<<endl<<flush;			 	
		}else{ 		
			//Recibe la peticion del filosofo para Levantarse	
  		nsentados--;
			cout<<"Camarero recibe una penticion para levantarse, hay "<< nsentados << " filosfos sentados." <<endl<<flush;	
		}
	}
}

int main(int argc,char** argv ){
 int rank,size;
 srand(time(0));

 MPI_Init( &argc, &argv );
 MPI_Comm_rank( MPI_COMM_WORLD, &rank );
 MPI_Comm_size( MPI_COMM_WORLD, &size );

 if( size!=11){
   if(rank == 0) 
      cout<<"El numero de procesos debe ser 10"<<endl<<flush;

   MPI_Finalize( ); return 0; 
 }

	if (rank == 10)
		Camarero();
 	else { if ((rank%2) == 0)
					Filosofo(rank,size-1); // Los pares son Filosofos 
			 	 else
					 Tenedor(rank,size-1);  // Los impares son Tenedores 
	}	
						
 MPI_Finalize();

 return 0;
}  

